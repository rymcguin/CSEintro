
/*
CSE 17
Ryan McGuiness
841369121
Homework #1   DEADLINE: May 23, 2019
Program: My Autobiography
*/

public class HW1 {
  public static void main (String[]args){
    String [] biography = {"I'm in the College of Arts & Sciences.", "I'm majoring in CSE & Economics.", 
      "My favorite class is CSE002.", "I'm going to be a Junior after this summer.",
      "I'm taking summer classes to graduate in 4 years."};
    
     int i = 0;
    for(i=0; i < biography.length; i++){
      System.out.println(biography[i]);
    }

  }
}
