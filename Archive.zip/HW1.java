
/*
CSE 17
Ryan McGuiness
841369121
Homework #1   DEADLINE: May 23, 2019
Program: My Autobiography
*/

public class HW1 {
  public static void main (String[]args){
    ArrayList<Date> dates = new ArrayList<>();
    dates.add(new Date());
    dates.add(new String());
    }

  }

