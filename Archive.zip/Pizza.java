public class Pizza{
  private int pepperoni;
  private int cheese;
  /**
 * Constructor
 */
  public Pizza(){
   this(0);
  }
  /**
 * Constrictor for pepperoni pizza
 */
  public Pizza(int pepperoni){
    this.pepperoni = pepperoni;
    this.cheese = 1;
   
  }
  /**
 * Informs user if the Pizza order had pepperoni on it. 
 */
  public boolean getPepperoni(){
    return pepperoni == 1;
  }

  /**
 * Returns the type of pizza ordered.
 */
  @Override
  public String toString() {
    if (getPepperoni()) {
      return "Pepperoni Pizza";
    }else{
    return "Cheese Pizza";
    }
  }
}